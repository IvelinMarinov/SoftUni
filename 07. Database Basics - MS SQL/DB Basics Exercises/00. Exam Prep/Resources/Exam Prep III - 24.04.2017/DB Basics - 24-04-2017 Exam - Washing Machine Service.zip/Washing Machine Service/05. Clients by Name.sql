SELECT FirstName, LastName, Phone FROM Clients
ORDER BY LastName, ClientId